
import { GoogleGenAI, Type } from "@google/genai";
import { Review } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Summarizes user reviews to give a "Vibe Check" to the host.
 */
export async function getVibeCheck(reviews: Review[], type: 'Host' | 'Guest') {
  if (reviews.length === 0) return "No history yet. Be the first to vibe with them!";
  
  const reviewText = reviews.map(r => `${r.rating} stars: ${r.content}`).join('\n');
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a helpful assistant for CambuApp, a party social network. 
      Analyze these ${type} reviews and give a short (2-sentence max) "Vibe Check" summary of what to expect from this person. 
      Be casual, energetic, and honest.
      
      Reviews:
      ${reviewText}`,
    });
    return response.text?.trim() || "Vibe analysis currently unavailable.";
  } catch (err) {
    console.error("Gemini Error:", err);
    return "The stars are currently unaligned. Use your intuition!";
  }
}

/**
 * Verifies ID using Gemini 3 Pro Vision to extract age.
 */
export async function verifyID(base64Image: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        { text: "Analyze this ID document. Extract the age of the person. Return ONLY a JSON object with 'age' (number) and 'isLegit' (boolean). Do not explain anything else." },
      ],
      config: {
        responseMimeType: "application/json",
      }
    });
    const result = JSON.parse(response.text || "{}");
    return result;
  } catch (err) {
    console.error("ID Verification Error:", err);
    return null;
  }
}

/**
 * Analyzes a party-related image using Gemini 3 Pro.
 */
export async function analyzePartyImage(base64Image: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        { text: "Describe the vibe of this image and list 3 items or themes that would fit a party inspired by this picture. Keep it brief and cool." },
      ],
    });
    return response.text || "Could not analyze the image vibe.";
  } catch (err) {
    console.error("Image Analysis Error:", err);
    return "Error analyzing image.";
  }
}

/**
 * Gets local neighborhood insights using Google Maps tool.
 */
export async function getNeighborhoodInsights(location: string, lat?: number, lng?: number) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `What's the vibe of ${location} for a party? List 3 cool nearby spots like bars, parks or stores that would be great for guests to visit before or after.`,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: lat && lng ? {
            latLng: { latitude: lat, longitude: lng }
          } : undefined
        }
      },
    });
    return response.text || "No specific local insights found.";
  } catch (err) {
    console.error("Maps Grounding Error:", err);
    return "Local insights temporarily unavailable.";
  }
}
