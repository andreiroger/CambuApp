
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Plus, Search, User as UserIcon, Calendar, MapPin, Star, Check, X, 
  Sparkles, DollarSign, Package, Info, Clock, ChevronRight, 
  ShieldCheck, AlertCircle, Wine, Home, UserCheck, ShoppingBag, Coffee,
  Locate, Globe, ExternalLink, Navigation, ChevronDown, Camera, Map as MapIcon,
  Settings, LogOut, SlidersHorizontal, ArrowLeft, Mail, Fingerprint, Trash2,
  Phone, AtSign, Cake, Heart, MessageSquare
} from 'lucide-react';
import { Party, User, ViewState, PartyRequest, Review, Ad, FilterOptions } from './types';
import { CURRENT_USER, INITIAL_PARTIES, MOCK_USERS, MOCK_ADS, COUNTRY_DATA } from './constants';
import { getVibeCheck, analyzePartyImage, getNeighborhoodInsights, verifyID } from './geminiService';

// --- Helpers ---
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

const getAge = (dobString: string) => {
  if (!dobString) return 0;
  const today = new Date();
  const birthDate = new Date(dobString);
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) age--;
  return age;
};

// --- Sub Components ---

const ReviewCard = ({ review }: { review: Review }) => (
  <div className="glass p-5 rounded-3xl border border-white/5 space-y-3">
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <img src={review.authorAvatar} className="w-10 h-10 rounded-xl object-cover" alt={review.authorName} />
        <div>
          <p className="text-xs font-black text-white">@{review.authorName}</p>
          <p className="text-[10px] font-medium text-slate-500">{review.date}</p>
        </div>
      </div>
      <div className="flex gap-0.5">
        {[...Array(5)].map((_, i) => (
          <Star key={i} size={10} className={i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-slate-700"} />
        ))}
      </div>
    </div>
    <p className="text-sm text-slate-300 leading-relaxed font-medium">"{review.content}"</p>
  </div>
);

const UserProfilePreview = ({ user, type }: { user: User, type: 'Host' | 'Guest' }) => {
  const reviews = type === 'Host' ? user.reviewsAsHost : user.reviewsAsGuest;
  return (
    <div className="flex flex-col gap-4 bg-slate-900/50 p-6 rounded-[32px] border border-slate-800">
      <div className="flex items-center gap-4">
        <img src={user.avatar} className="w-16 h-16 rounded-2xl border-2 border-indigo-500 object-cover shadow-2xl" alt={user.username} />
        <div>
          <p className="font-black text-lg text-white">@{user.username}</p>
          <div className="flex items-center gap-2">
            <RatingStars rating={type === 'Host' ? user.hostRating : user.guestRating} />
            <span className="text-[10px] font-black text-slate-500 uppercase">{getAge(user.dob)} YEARS</span>
          </div>
        </div>
      </div>
      <div className="space-y-4">
        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Recent Reviews</p>
        <div className="space-y-3">
          {reviews.slice(0, 2).map(r => <ReviewCard key={r.id} review={r} />)}
          {reviews.length === 0 && <p className="text-xs text-slate-600 italic">No reviews yet for this category.</p>}
        </div>
      </div>
    </div>
  );
};

const RatingStars = ({ rating }: { rating: number }) => (
  <div className="flex items-center gap-0.5">
    {[...Array(5)].map((_, i) => (
      <Star key={i} size={10} className={i < Math.floor(rating) ? "fill-yellow-400 text-yellow-400" : "text-slate-600"} />
    ))}
    <span className="text-[10px] font-black text-slate-400 ml-1">{rating.toFixed(1)}</span>
  </div>
);

// --- Main App ---

export default function App() {
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem('cambu_user_v2');
    return saved ? JSON.parse(saved) : CURRENT_USER;
  });

  const [view, setView] = useState<ViewState>(() => {
    if (!currentUser.fullName || currentUser.fullName === 'Alex Rivera') return 'auth';
    if (!currentUser.city) return 'onboarding';
    return 'browse';
  });

  const [parties, setParties] = useState<Party[]>(INITIAL_PARTIES);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [selectedParty, setSelectedParty] = useState<Party | null>(null);
  const [requestingToJoin, setRequestingToJoin] = useState<Party | null>(null);
  const [requestPledge, setRequestPledge] = useState('');
  const [requestMessage, setRequestMessage] = useState('');
  const [filters, setFilters] = useState<FilterOptions>({ sortBy: 'distance', maxPrice: 200, theme: 'All' });
  const [showFilters, setShowFilters] = useState(false);

  // ID & Onboarding
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [onboardingData, setOnboardingData] = useState({ 
    username: '', fullName: '', nickname: '', dob: '', email: '', phone: '', bio: '', avatar: 'https://picsum.photos/seed/new/200' 
  });
  const [onboardingCountry, setOnboardingCountry] = useState('');
  const [onboardingCity, setOnboardingCity] = useState('');
  const [onboardingAddress, setOnboardingAddress] = useState('');

  // Camera & Verification
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    localStorage.setItem('cambu_user_v2', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    let stream: MediaStream | null = null;
    if (isCameraOpen) {
      navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
        .then(s => {
          stream = s;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
          }
        })
        .catch(err => {
          console.error("Camera error:", err);
          alert("Could not access camera. Please allow camera permissions.");
          setIsCameraOpen(false);
        });
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach(t => t.stop());
      }
    };
  }, [isCameraOpen]);

  // Derived
  const filteredParties = useMemo(() => {
    let list = parties.filter(p => {
      // REQUIREMENT: REMOVE FROM PLATFORM WHEN FULL
      if (p.currentGuests.length >= p.maxGuests) return false;

      const matchesLocation = !currentUser.city || (p.city === currentUser.city);
      const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           p.theme.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPrice = (p.price || 0) <= filters.maxPrice;
      const matchesTheme = filters.theme === 'All' || p.theme.includes(filters.theme);
      
      return matchesLocation && matchesSearch && matchesPrice && matchesTheme;
    });

    if (filters.sortBy === 'distance' && currentUser.location) {
      list.sort((a, b) => {
        const distA = calculateDistance(currentUser.location!.latitude, currentUser.location!.longitude, a.preciseLocation.latitude, a.preciseLocation.longitude);
        const distB = calculateDistance(currentUser.location!.latitude, currentUser.location!.longitude, b.preciseLocation.latitude, b.preciseLocation.longitude);
        return distA - distB;
      });
    } else if (filters.sortBy === 'price') {
      list.sort((a, b) => (a.price || 0) - (b.price || 0));
    }
    return list;
  }, [parties, searchQuery, currentUser, filters]);

  const hostingParties = useMemo(() => parties.filter(p => p.hostId === currentUser.id), [parties, currentUser]);
  const attendingParties = useMemo(() => parties.filter(p => p.currentGuests.includes(currentUser.id)), [parties, currentUser]);

  const handleCreateParty = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const p: Party = {
      id: `p${Date.now()}`,
      hostId: currentUser.id,
      hostName: currentUser.username,
      title: form.party_title.value,
      theme: form.party_theme.value,
      description: form.party_desc.value,
      date: form.party_date.value,
      locationName: form.party_hood.value,
      city: currentUser.city,
      country: currentUser.country,
      exactAddress: form.party_addr.value,
      preciseLocation: currentUser.location || { latitude: 40.7, longitude: -74.0 },
      maxGuests: parseInt(form.party_max.value),
      currentGuests: [],
      pendingRequests: [],
      price: parseInt(form.party_price.value) || 0,
      whatToBring: form.party_bring.value.split(',').map((s: string) => s.trim()),
      imageUrl: `https://picsum.photos/seed/${Math.random()}/800/400`,
      galleryUrls: [],
      includesAlcohol: form.party_alcohol?.checked || false
    };
    setParties([p, ...parties]);
    setIsCreating(false);
  };

  const handleRequestAction = (partyId: string, requestId: string, action: 'accept' | 'decline') => {
    setParties(prev => prev.map(p => {
      if (p.id === partyId) {
        const req = p.pendingRequests.find(r => r.id === requestId);
        if (!req) return p;
        if (action === 'accept') {
          return { 
            ...p, 
            currentGuests: [...p.currentGuests, req.userId], 
            pendingRequests: p.pendingRequests.filter(r => r.id !== requestId) 
          };
        }
        return { ...p, pendingRequests: p.pendingRequests.filter(r => r.id !== requestId) };
      }
      return p;
    }));
  };

  const submitJoinRequest = () => {
    if (!requestingToJoin) return;
    const newRequest: PartyRequest = {
      id: `req-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.username,
      userFullName: currentUser.fullName,
      userPhone: currentUser.phone,
      userAvatar: currentUser.avatar,
      message: requestMessage,
      pledgedItems: requestPledge,
      status: 'pending'
    };
    setParties(prev => prev.map(p => {
      if (p.id === requestingToJoin.id) {
        return { ...p, pendingRequests: [...p.pendingRequests, newRequest] };
      }
      return p;
    }));
    setRequestingToJoin(null);
    setRequestMessage('');
    setRequestPledge('');
  };

  const handleCaptureId = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    const context = canvasRef.current.getContext('2d');
    if (!context) return;
    
    // Set canvas dimensions to match video
    canvasRef.current.width = videoRef.current.videoWidth;
    canvasRef.current.height = videoRef.current.videoHeight;
    
    // Draw video frame to canvas
    context.drawImage(videoRef.current, 0, 0);
    
    // Get base64 data
    const base64Data = canvasRef.current.toDataURL('image/jpeg').split(',')[1];
    
    setVerifying(true);
    const result = await verifyID(base64Data);
    
    if (result && result.isLegit) {
      setCurrentUser(prev => ({ ...prev, isIdVerified: true }));
      // Optionally update age if Gemini returned it confidentially
      // if (result.age) setCurrentUser(prev => ({ ...prev, age: result.age }));
      alert(`Success! ID Verified. Age detected: ${result.age}`);
      setIsCameraOpen(false);
    } else {
      alert("Verification failed. Could not read ID or age check failed.");
    }
    setVerifying(false);
  };

  if (view === 'auth') {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6">
        <div className="glass max-w-sm w-full rounded-[40px] p-12 text-center border border-white/5">
          <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center rotate-3 mx-auto mb-10 shadow-3xl shadow-indigo-600/20">
            <Sparkles className="text-white" size={42} />
          </div>
          <h2 className="text-4xl font-black mb-4 tracking-tighter">CAMBU</h2>
          <p className="text-slate-500 mb-12 font-bold uppercase text-[10px] tracking-widest">Connect through vibes</p>
          <button 
            onClick={() => setView('onboarding')}
            className="w-full py-5 bg-white text-slate-950 font-black rounded-3xl transition-all shadow-xl hover:scale-105 active:scale-95"
          >
            GET STARTED
          </button>
        </div>
      </div>
    );
  }

  if (view === 'onboarding') {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6">
        <div className="glass max-w-xl w-full rounded-[40px] p-8 sm:p-12 border border-white/10 shadow-3xl">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-black">Profile Builder</h2>
            <span className="text-[10px] font-black text-slate-500 uppercase">Step {onboardingStep} of 2</span>
          </div>

          {onboardingStep === 1 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Username <span className="text-rose-500">*</span></label>
                  <input placeholder="e.g. andrei_roger" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold focus:border-indigo-500 outline-none" value={onboardingData.username} onChange={e => setOnboardingData({...onboardingData, username: e.target.value})} />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Full Name <span className="text-rose-500">*</span></label>
                  <input placeholder="e.g. Andrei Roger" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold focus:border-indigo-500 outline-none" value={onboardingData.fullName} onChange={e => setOnboardingData({...onboardingData, fullName: e.target.value})} />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Email <span className="text-rose-500">*</span></label>
                  <input placeholder="hello@cambu.app" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold focus:border-indigo-500 outline-none" value={onboardingData.email} onChange={e => setOnboardingData({...onboardingData, email: e.target.value})} />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Phone <span className="text-rose-500">*</span></label>
                  <input placeholder="+1..." className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold focus:border-indigo-500 outline-none" value={onboardingData.phone} onChange={e => setOnboardingData({...onboardingData, phone: e.target.value})} />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Birth Date <span className="text-rose-500">*</span></label>
                  <input type="date" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold focus:border-indigo-500 outline-none" value={onboardingData.dob} onChange={e => setOnboardingData({...onboardingData, dob: e.target.value})} />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Nickname (Optional)</label>
                  <input placeholder="e.g. Roger" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold focus:border-indigo-500 outline-none" value={onboardingData.nickname} onChange={e => setOnboardingData({...onboardingData, nickname: e.target.value})} />
                </div>
              </div>
              <button 
                disabled={!onboardingData.username || !onboardingData.fullName || !onboardingData.email || !onboardingData.phone || !onboardingData.dob}
                onClick={() => setOnboardingStep(2)}
                className="w-full py-5 bg-indigo-600 text-white font-black rounded-3xl disabled:opacity-50 shadow-2xl shadow-indigo-600/20"
              >
                CONTINUE
              </button>
            </div>
          )}

          {onboardingStep === 2 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Country <span className="text-rose-500">*</span></label>
                <select value={onboardingCountry} onChange={e => setOnboardingCountry(e.target.value)} className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold outline-none">
                  <option value="">Select Country</option>
                  {Object.keys(COUNTRY_DATA).map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">City <span className="text-rose-500">*</span></label>
                <input placeholder="e.g. Bristol" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold focus:border-indigo-500 outline-none" value={onboardingCity} onChange={e => setOnboardingCity(e.target.value)} />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Address <span className="text-rose-500">*</span></label>
                <input placeholder="Full address" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl px-6 py-4 text-white font-bold focus:border-indigo-500 outline-none" value={onboardingAddress} onChange={e => setOnboardingAddress(e.target.value)} />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Bio (Optional)</label>
                <textarea rows={3} placeholder="Tell us what you like..." className="w-full bg-slate-900 border-2 border-slate-800 rounded-3xl px-6 py-4 text-white font-bold outline-none resize-none" value={onboardingData.bio} onChange={e => setOnboardingData({...onboardingData, bio: e.target.value})} />
              </div>
              <button 
                disabled={!onboardingCountry || !onboardingCity || !onboardingAddress}
                onClick={() => {
                  setCurrentUser(prev => ({
                    ...prev,
                    ...onboardingData,
                    city: onboardingCity,
                    country: onboardingCountry,
                    address: onboardingAddress
                  }));
                  setView('browse');
                }}
                className="w-full py-5 bg-indigo-600 text-white font-black rounded-3xl shadow-2xl shadow-indigo-600/20"
              >
                COMPLETE PROFILE
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-32 bg-[#080d1a]">
      <header className="sticky top-0 z-40 glass border-b border-white/5 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView('browse')}>
          <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center rotate-3"><Sparkles className="text-white" size={24} /></div>
          <div>
            <h1 className="text-xl font-black tracking-tighter text-white">CAMBU</h1>
            <p className="text-[8px] font-black text-indigo-400 uppercase tracking-widest">{currentUser.city || 'Global'}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setIsCreating(true)} className="p-3 bg-indigo-600 hover:bg-indigo-500 rounded-2xl shadow-lg transition-all active:scale-90"><Plus className="text-white" size={24} /></button>
          <img src={currentUser.avatar} onClick={() => setView('profile')} className="w-11 h-11 rounded-2xl border-2 border-slate-800 cursor-pointer object-cover" alt="Me" />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 pt-10">
        {view === 'browse' && (
          <div className="space-y-12">
            <div className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto">
              <div className="relative flex-1">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                <input type="text" placeholder="Search vibes..." className="w-full bg-slate-900 border-2 border-slate-800 rounded-3xl py-4 pl-14 pr-6 text-white font-bold outline-none focus:border-indigo-500" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              </div>
              <button onClick={() => setShowFilters(!showFilters)} className="px-6 py-4 bg-slate-900 border-2 border-slate-800 rounded-3xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-white transition-all">Filters</button>
            </div>

            {showFilters && (
              <div className="max-w-2xl mx-auto glass p-8 rounded-[40px] border-indigo-500/20 grid grid-cols-1 sm:grid-cols-2 gap-8 animate-in slide-in-from-top-4">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Max Price: ${filters.maxPrice}</label>
                  <input type="range" min="0" max="500" step="10" className="w-full accent-indigo-500" value={filters.maxPrice} onChange={e => setFilters({...filters, maxPrice: parseInt(e.target.value)})} />
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Theme</label>
                  <select className="w-full bg-slate-800 border-2 border-slate-700 rounded-2xl px-4 py-3 text-xs font-black text-white outline-none" value={filters.theme} onChange={e => setFilters({...filters, theme: e.target.value})}>
                    <option>All</option>
                    <option>Cyberpunk / Neon</option>
                    <option>Casual / Foodie</option>
                  </select>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              {filteredParties.map(p => (
                <div key={p.id} onClick={() => setSelectedParty(p)} className="glass rounded-[40px] overflow-hidden hover:-translate-y-2 transition-all cursor-pointer border border-white/5 group shadow-2xl">
                  <div className="relative h-60 overflow-hidden">
                    <img src={p.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={p.title} />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
                    <div className="absolute top-5 left-5 flex gap-2">
                      <span className="px-3 py-1 bg-black/40 backdrop-blur rounded-xl text-[10px] font-black uppercase text-white">{p.theme}</span>
                      {p.price! > 0 && <span className="px-3 py-1 bg-emerald-600 rounded-xl text-[10px] font-black uppercase text-white shadow-xl">${p.price}</span>}
                    </div>
                  </div>
                  <div className="p-8 space-y-4">
                    <h3 className="text-2xl font-black leading-tight truncate">{p.title}</h3>
                    <div className="flex items-center justify-between text-[10px] font-black text-slate-500 uppercase tracking-widest">
                      <div className="flex items-center gap-1"><MapPin size={12} className="text-indigo-500" /> {p.locationName}</div>
                      <div>{p.maxGuests - p.currentGuests.length} SPOTS LEFT</div>
                    </div>
                    <div className="flex items-center justify-between pt-4">
                      <div className="flex -space-x-3">
                        {p.currentGuests.slice(0, 4).map(gid => (
                          <img key={gid} src={MOCK_USERS[gid]?.avatar || 'https://picsum.photos/seed/guest/100'} className="w-9 h-9 rounded-xl border-4 border-slate-900 object-cover" alt="Guest" />
                        ))}
                        {p.currentGuests.length > 4 && <div className="w-9 h-9 rounded-xl border-4 border-slate-900 bg-slate-800 flex items-center justify-center text-[10px] font-black text-white">+{p.currentGuests.length - 4}</div>}
                      </div>
                      <button className="px-6 py-3 bg-indigo-600 rounded-2xl text-[10px] font-black uppercase shadow-xl shadow-indigo-600/20 group-hover:bg-white group-hover:text-slate-950 transition-all">JOIN VIBE</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {view === 'host' && (
          <div className="space-y-10 max-w-5xl mx-auto">
            <h2 className="text-4xl font-black">Your Events</h2>
            {hostingParties.map(p => (
              <div key={p.id} className="glass rounded-[40px] p-8 border border-white/5 space-y-10">
                <div className="flex flex-col md:flex-row gap-10">
                  <img src={p.imageUrl} className="w-full md:w-72 h-48 rounded-3xl object-cover shadow-2xl" alt={p.title} />
                  <div className="flex-1 space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-3xl font-black">{p.title}</h3>
                      <span className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-2xl text-[10px] font-black uppercase text-indigo-400">{p.currentGuests.length} / {p.maxGuests} GUESTS</span>
                    </div>
                    <p className="text-slate-400 text-sm leading-relaxed">{p.description}</p>
                    <div className="flex flex-wrap gap-3">
                      {p.currentGuests.map(gid => {
                        const guest = MOCK_USERS[gid] || { username: 'unknown', fullName: 'Unknown Guest', phone: 'Hidden', avatar: 'https://picsum.photos/seed/unknown/100' };
                        return (
                          <div key={gid} className="flex items-center gap-3 bg-indigo-500/5 p-3 rounded-2xl border border-indigo-500/10">
                            <img src={guest.avatar} className="w-8 h-8 rounded-xl object-cover" alt={guest.username} />
                            <div>
                              <p className="text-xs font-black">@{guest.username}</p>
                              <p className="text-[8px] font-bold text-slate-500 truncate">{guest.fullName} • {guest.phone}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Entry Requests ({p.pendingRequests.length})</p>
                  <div className="grid gap-4">
                    {p.pendingRequests.map(req => (
                      <div key={req.id} className="bg-slate-900 border border-slate-800 p-6 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-6">
                        <div className="flex items-center gap-5">
                          <img src={req.userAvatar} className="w-16 h-16 rounded-2xl border-2 border-indigo-500/20 object-cover" alt={req.userName} />
                          <div>
                            <p className="text-lg font-black text-white">@{req.userName}</p>
                            <p className="text-sm text-slate-400 italic">" {req.message} "</p>
                            <p className="text-[10px] font-black text-indigo-500 uppercase mt-2">Pledge: {req.pledgedItems}</p>
                          </div>
                        </div>
                        <div className="flex gap-3">
                          <button onClick={() => handleRequestAction(p.id, req.id, 'accept')} className="p-4 bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500 hover:text-white rounded-2xl transition-all"><Check size={20}/></button>
                          <button onClick={() => handleRequestAction(p.id, req.id, 'decline')} className="p-4 bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white rounded-2xl transition-all"><X size={20}/></button>
                        </div>
                      </div>
                    ))}
                    {p.pendingRequests.length === 0 && <p className="text-xs text-slate-600 italic">No pending requests.</p>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {view === 'profile' && (
          <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in duration-700">
            {/* Header Profile Section */}
            <div className="glass rounded-[50px] p-10 sm:p-16 text-center relative border border-white/5 shadow-3xl">
              <div className="absolute top-0 inset-x-0 h-40 bg-indigo-600/10 blur-[100px] pointer-events-none" />
              <div className="relative inline-block mb-10">
                <img src={currentUser.avatar} className="w-40 h-40 rounded-[40px] border-4 border-slate-950 shadow-3xl rotate-3 object-cover mx-auto" alt={currentUser.username} />
                <div className="absolute -bottom-4 -right-4 bg-indigo-600 p-4 rounded-3xl shadow-2xl rotate-12"><Heart size={24} className="text-white fill-white" /></div>
              </div>
              
              <div className="flex items-center justify-center gap-4 mb-3">
                <h2 className="text-5xl font-black tracking-tighter">@{currentUser.username}</h2>
                {currentUser.isIdVerified ? (
                  <VerifiedBadge size={28}/>
                ) : (
                  <button onClick={() => setIsCameraOpen(true)} className="px-5 py-3 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-indigo-500 transition-all shadow-lg flex items-center gap-2 animate-bounce">
                    <Camera size={16} /> Verify ID
                  </button>
                )}
              </div>
              
              <p className="text-xl font-black text-slate-200">{currentUser.fullName} {currentUser.nickname && <span className="text-slate-500 font-medium">({currentUser.nickname})</span>}</p>
              
              <div className="flex flex-wrap justify-center gap-6 mt-10">
                <div className="px-6 py-4 bg-slate-900 border border-slate-800 rounded-3xl flex items-center gap-3">
                  <Cake className="text-indigo-500" size={20} />
                  <span className="text-sm font-black text-slate-300">{getAge(currentUser.dob)} YEARS OLD</span>
                </div>
                <div className="px-6 py-4 bg-slate-900 border border-slate-800 rounded-3xl flex items-center gap-3">
                  <MapPin className="text-indigo-500" size={20} />
                  <span className="text-sm font-black text-slate-300">{currentUser.city}, {currentUser.country}</span>
                </div>
                <div className="px-6 py-4 bg-slate-900 border border-slate-800 rounded-3xl flex items-center gap-3">
                  <Phone className="text-indigo-500" size={20} />
                  <span className="text-sm font-black text-slate-300">{currentUser.phone}</span>
                </div>
                <div className="px-6 py-4 bg-slate-900 border border-slate-800 rounded-3xl flex items-center gap-3">
                  <AtSign className="text-indigo-500" size={20} />
                  <span className="text-sm font-black text-slate-300">{currentUser.email}</span>
                </div>
              </div>

              <div className="mt-12 pt-12 border-t border-slate-800/50 max-w-xl mx-auto">
                <p className="text-lg text-slate-400 font-medium leading-relaxed italic">"{currentUser.bio}"</p>
              </div>

              <div className="grid grid-cols-2 gap-6 mt-16 max-w-lg mx-auto">
                <div className="bg-slate-900/80 p-8 rounded-[40px] border border-slate-800 text-left space-y-2">
                  <div className="flex justify-between items-center"><Home size={20} className="text-indigo-400"/><span className="text-[10px] font-black uppercase text-indigo-400">Host Rep</span></div>
                  <h4 className="text-4xl font-black text-white">{currentUser.hostRating.toFixed(1)}</h4>
                  <RatingStars rating={currentUser.hostRating} />
                </div>
                <div className="bg-slate-900/80 p-8 rounded-[40px] border border-slate-800 text-left space-y-2">
                  <div className="flex justify-between items-center"><UserIcon size={20} className="text-emerald-400"/><span className="text-[10px] font-black uppercase text-emerald-400">Guest Rep</span></div>
                  <h4 className="text-4xl font-black text-white">{currentUser.guestRating.toFixed(1)}</h4>
                  <RatingStars rating={currentUser.guestRating} />
                </div>
              </div>
            </div>

            {/* Detailed Reviews Section */}
            <div className="space-y-10">
              <h3 className="text-3xl font-black px-4">Latest Reviews</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="flex items-center justify-between px-4">
                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em]">As a Host</p>
                    <span className="text-[10px] font-bold text-slate-600">{currentUser.reviewsAsHost.length} Total</span>
                  </div>
                  <div className="space-y-4">
                    {currentUser.reviewsAsHost.map(r => <ReviewCard key={r.id} review={r} />)}
                    {currentUser.reviewsAsHost.length === 0 && <p className="px-4 text-xs text-slate-600 italic">No host reviews yet.</p>}
                  </div>
                </div>
                <div className="space-y-6">
                  <div className="flex items-center justify-between px-4">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.2em]">As a Guest</p>
                    <span className="text-[10px] font-bold text-slate-600">{currentUser.reviewsAsGuest.length} Total</span>
                  </div>
                  <div className="space-y-4">
                    {currentUser.reviewsAsGuest.map(r => <ReviewCard key={r.id} review={r} />)}
                    {currentUser.reviewsAsGuest.length === 0 && <p className="px-4 text-xs text-slate-600 italic">No guest reviews yet.</p>}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Detail Modal */}
      {selectedParty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-xl overflow-y-auto">
          <div className="glass w-full max-w-5xl min-h-[85vh] rounded-[50px] overflow-hidden shadow-3xl relative animate-in zoom-in-95 duration-500">
            <button onClick={() => setSelectedParty(null)} className="absolute top-8 right-8 z-10 p-4 bg-black/40 text-white rounded-full hover:bg-indigo-600 transition-all active:scale-90"><X size={24}/></button>
            <div className="flex flex-col lg:row h-full">
              <div className="w-full lg:w-[45%] h-[400px] lg:h-auto relative shrink-0">
                <img src={selectedParty.imageUrl} className="w-full h-full object-cover" alt={selectedParty.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
                <div className="absolute bottom-10 left-10 right-10 space-y-4">
                  <div className="flex gap-2"><span className="px-4 py-2 bg-indigo-600 rounded-2xl text-[10px] font-black uppercase text-white shadow-2xl">{selectedParty.theme}</span></div>
                  <h2 className="text-5xl font-black text-white leading-tight">{selectedParty.title}</h2>
                  <div className="flex items-center gap-4">
                     <div className="flex items-center gap-2 text-emerald-400 font-black"><DollarSign size={20}/> {selectedParty.price || 0}</div>
                     <div className="flex items-center gap-2 text-indigo-400 font-black"><MapPin size={20}/> {selectedParty.locationName}</div>
                  </div>
                </div>
              </div>
              <div className="flex-1 p-10 lg:p-16 space-y-10 overflow-y-auto bg-slate-950/30">
                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">About the Vibe</p>
                   <p className="text-xl text-slate-300 leading-relaxed font-medium">{selectedParty.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-2"><ShoppingBag size={14}/> Must Bring</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedParty.whatToBring.map((item, i) => <span key={i} className="px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-bold rounded-xl">{item}</span>)}
                    </div>
                  </div>
                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2"><UserCheck size={14}/> Attending ({selectedParty.currentGuests.length})</p>
                    <div className="flex -space-x-2">
                      {selectedParty.currentGuests.map(gid => (
                        <img key={gid} src={MOCK_USERS[gid]?.avatar} className="w-10 h-10 rounded-xl border-4 border-slate-900 object-cover hover:translate-y-[-4px] transition-all cursor-pointer" alt="Guest" />
                      ))}
                    </div>
                  </div>
                </div>

                {selectedParty.galleryUrls.length > 0 && (
                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Past Vibes</p>
                    <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
                      {selectedParty.galleryUrls.map((url, i) => (
                        <img key={i} src={url} className="w-32 h-32 rounded-3xl object-cover shrink-0 border border-white/5 shadow-xl" alt="Gallery" />
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-10 border-t border-slate-800">
                   <p className="text-[10px] font-black text-slate-500 uppercase mb-6 tracking-widest">The Host</p>
                   <UserProfilePreview user={MOCK_USERS[selectedParty.hostId] || currentUser} type="Host" />
                </div>

                <button 
                  onClick={() => { setRequestingToJoin(selectedParty); setSelectedParty(null); }}
                  className="w-full py-6 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xl rounded-3xl shadow-3xl shadow-indigo-600/20 active:scale-95 transition-all"
                >
                  REQUEST ENTRY
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* JOIN REQUEST MODAL */}
      {requestingToJoin && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-950/95 backdrop-blur-3xl">
          <div className="glass w-full max-w-xl rounded-[40px] p-10 border border-white/10 shadow-3xl animate-in zoom-in-95">
            <h2 className="text-3xl font-black mb-8">Request Entry</h2>
            <div className="space-y-8">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-indigo-400 uppercase ml-2 tracking-widest">Pledge (What you're bringing)</label>
                <div className="relative">
                  <Package className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                  <input placeholder="e.g. 2 Bottles of Cider" className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl pl-16 pr-6 py-5 text-white font-bold outline-none focus:border-indigo-500" value={requestPledge} onChange={e => setRequestPledge(e.target.value)} />
                </div>
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black text-indigo-400 uppercase ml-2 tracking-widest">Message to Host</label>
                <div className="relative">
                  <MessageSquare className="absolute left-6 top-6 text-slate-500" size={20} />
                  <textarea rows={3} placeholder="Hey! Excited for the beats..." className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl pl-16 pr-6 py-5 text-white font-bold outline-none focus:border-indigo-500 resize-none" value={requestMessage} onChange={e => setRequestMessage(e.target.value)} />
                </div>
              </div>
              <div className="flex gap-4">
                <button onClick={() => setRequestingToJoin(null)} className="flex-1 py-5 bg-slate-800 text-white font-black rounded-3xl active:scale-95 transition-all">CANCEL</button>
                <button onClick={submitJoinRequest} className="flex-2 py-5 bg-indigo-600 text-white font-black rounded-3xl shadow-2xl shadow-indigo-600/20 active:scale-95 transition-all">SEND REQUEST</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CREATE MODAL */}
      {isCreating && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-6 bg-slate-950/90 backdrop-blur-2xl">
           <div className="glass w-full max-w-3xl h-[95vh] sm:h-auto sm:max-h-[90vh] rounded-t-[50px] sm:rounded-[50px] p-8 sm:p-12 overflow-y-auto animate-in slide-in-from-bottom-full duration-500">
              <div className="flex justify-between items-center mb-10">
                 <h2 className="text-4xl font-black">Host New Vibe</h2>
                 <button onClick={() => setIsCreating(false)} className="p-4 bg-slate-900 rounded-full hover:bg-rose-500 transition-all"><X/></button>
              </div>
              <form onSubmit={handleCreateParty} className="space-y-8 pb-20">
                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-indigo-400 ml-2">Party Title</label>
                       <input name="party_title" required placeholder="e.g. Moonlight Bass" className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl px-8 py-5 outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-indigo-400 ml-2">Neighborhood</label>
                       <input name="party_hood" required placeholder="e.g. West End" className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl px-8 py-5 outline-none" />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-indigo-400 ml-2">Exact Address (Shared on Accept)</label>
                    <input name="party_addr" required placeholder="123 Vibe Ave, Unit 9" className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl px-8 py-5 outline-none" />
                 </div>
                 <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="space-y-2 col-span-2">
                       <label className="text-[10px] font-black uppercase text-indigo-400 ml-2">Theme</label>
                       <input name="party_theme" required className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl px-8 py-5 outline-none" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-indigo-400 ml-2">Max Spots</label>
                       <input name="party_max" type="number" required className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl px-8 py-5 outline-none" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-indigo-400 ml-2">Entry ($)</label>
                       <input name="party_price" type="number" className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl px-8 py-5 outline-none" />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-indigo-400 ml-2">What to bring (e.g. Snacks, Soda)</label>
                    <input name="party_bring" className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl px-8 py-5 outline-none" />
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-indigo-400 ml-2">Vibe Description</label>
                    <textarea name="party_desc" rows={3} className="w-full bg-slate-950 border-2 border-slate-800 rounded-[40px] px-8 py-6 outline-none resize-none" />
                 </div>
                 <div className="flex items-center justify-between p-8 bg-slate-900 rounded-[40px] border border-slate-800">
                    <div>
                      <p className="font-black text-white">18+ ALCOHOL EVENT</p>
                      <p className="text-[10px] text-slate-500 font-bold tracking-widest">REQUIRES ID SCAN FOR ENTRY</p>
                    </div>
                    <input name="party_alcohol" type="checkbox" className="w-8 h-8 accent-indigo-500" />
                 </div>
                 <button className="w-full py-6 bg-indigo-600 rounded-[40px] font-black text-2xl shadow-3xl shadow-indigo-600/30 hover:scale-105 active:scale-95 transition-all">PUBLISH VIBE</button>
              </form>
           </div>
        </div>
      )}

      {/* CAMERA MODAL */}
      {isCameraOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/90 p-4 animate-in fade-in duration-300">
          <div className="relative w-full max-w-lg bg-slate-900 rounded-[32px] overflow-hidden border border-slate-800 shadow-2xl">
            <button onClick={() => setIsCameraOpen(false)} className="absolute top-6 right-6 z-10 p-4 bg-black/50 text-white rounded-full hover:bg-rose-500 transition-all"><X size={24}/></button>
            <div className="relative aspect-[3/4] bg-black">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
              <canvas ref={canvasRef} className="hidden" />
              <div className="absolute inset-0 border-[40px] border-black/50 pointer-events-none">
                <div className="border-2 border-white/30 w-full h-full rounded-2xl relative">
                   <p className="absolute top-4 inset-x-0 text-center text-white/70 text-xs font-black uppercase tracking-widest">Align ID Here</p>
                </div>
              </div>
            </div>
            <div className="p-8 flex justify-center bg-slate-900 border-t border-slate-800">
              <button 
                onClick={handleCaptureId}
                disabled={verifying}
                className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed active:scale-90 transition-all hover:scale-105 hover:bg-white/10"
              >
                {verifying ? <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"/> : <div className="w-16 h-16 bg-white rounded-full" />}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MOBILE NAV */}
      <nav className="fixed bottom-6 inset-x-6 glass border border-white/10 p-2 flex justify-around md:hidden z-50 rounded-[35px] shadow-3xl backdrop-blur-3xl">
        <button onClick={() => setView('browse')} className={`p-4 rounded-3xl transition-all ${view === 'browse' ? 'bg-white text-slate-950' : 'text-slate-400'}`}><Search size={24} strokeWidth={3} /></button>
        <button onClick={() => setView('host')} className={`p-4 rounded-3xl transition-all ${view === 'host' ? 'bg-white text-slate-950' : 'text-slate-400'}`}><Home size={24} strokeWidth={3} /></button>
        <button onClick={() => setView('attending')} className={`p-4 rounded-3xl transition-all ${view === 'attending' ? 'bg-white text-slate-950' : 'text-slate-400'}`}><Calendar size={24} strokeWidth={3} /></button>
        <button onClick={() => setView('profile')} className={`p-4 rounded-3xl transition-all ${view === 'profile' ? 'bg-white text-slate-950' : 'text-slate-400'}`}><UserIcon size={24} strokeWidth={3} /></button>
      </nav>
    </div>
  );
}

// Reuse existing Sub Components with slight tweaks for detail level...
const VerifiedBadge = ({ size = 14 }: { size?: number }) => (
  <div className="bg-indigo-500 rounded-full p-1 shadow-lg" title="ID Verified">
    <ShieldCheck size={size} className="text-white" />
  </div>
);
