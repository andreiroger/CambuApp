
export interface User {
  id: string;
  username: string;
  fullName: string;
  nickname?: string;
  avatar: string;
  bio: string;
  isIdVerified: boolean;
  dob: string; // ISO string 'YYYY-MM-DD'
  email: string;
  phone: string;
  country: string;
  city: string;
  address: string;
  location?: {
    latitude: number;
    longitude: number;
  };
  hostRating: number;
  guestRating: number;
  reviewsAsHost: Review[];
  reviewsAsGuest: Review[];
  preferences: {
    notifications: boolean;
    darkMode: boolean;
    radius: number; // km
  };
}

export interface Review {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  rating: number;
  date: string;
  type: 'asHost' | 'asGuest';
}

export interface Party {
  id: string;
  hostId: string;
  hostName: string;
  title: string;
  theme: string;
  description: string;
  date: string;
  locationName: string; 
  city: string;
  country: string;
  exactAddress?: string; 
  preciseLocation: {
    latitude: number;
    longitude: number;
  };
  maxGuests: number;
  currentGuests: string[]; // List of User IDs
  pendingRequests: PartyRequest[];
  price?: number;
  whatToBring: string[];
  imageUrl: string;
  galleryUrls: string[]; // List of URLs for party vibes
  includesAlcohol: boolean;
}

export interface PartyRequest {
  id: string;
  userId: string;
  userName: string;
  userFullName: string;
  userPhone: string;
  userAvatar: string;
  message: string;
  pledgedItems: string;
  status: 'pending' | 'accepted' | 'declined';
}

export type ViewState = 'browse' | 'host' | 'attending' | 'profile' | 'onboarding' | 'settings' | 'auth';

export interface Ad {
  id: string;
  brand: string;
  image: string;
  tagline: string;
  isAdultOnly: boolean;
  cta: string;
}

export interface FilterOptions {
  sortBy: 'distance' | 'price' | 'newest';
  maxPrice: number;
  theme: string;
}
