
import { User, Party, Ad } from './types';

export const CURRENT_USER: User = {
  id: 'me',
  username: 'alex_vibes',
  fullName: 'Alex Rivera',
  nickname: 'Al',
  avatar: 'https://picsum.photos/seed/me/200',
  bio: 'Love house music and tech. Hosting the best rooftop vibes in town.',
  isIdVerified: false,
  dob: '1999-05-15',
  email: 'alex@example.com',
  phone: '+1 555-0123',
  country: 'USA',
  city: 'New York',
  address: '123 Broadway, NY',
  hostRating: 4.8,
  guestRating: 4.9,
  reviewsAsHost: [
    { 
      id: 'r1', 
      authorId: 'u2', 
      authorName: 'sarah_j', 
      authorAvatar: 'https://picsum.photos/seed/sarah/100',
      content: 'Incredible host! The drinks were flowing and the music was top notch. Really knows how to set a mood.', 
      rating: 5, 
      date: '2023-10-01', 
      type: 'asHost' 
    }
  ],
  reviewsAsGuest: [
    { 
      id: 'r2', 
      authorId: 'u3', 
      authorName: 'marcus_pizza', 
      authorAvatar: 'https://picsum.photos/seed/marcus/100',
      content: 'Respectful, helped clean up after the pizza party. Would definitely invite again.', 
      rating: 5, 
      date: '2023-09-15', 
      type: 'asGuest' 
    }
  ],
  preferences: {
    notifications: true,
    darkMode: true,
    radius: 50
  }
};

export const COUNTRY_DATA: Record<string, string[]> = {
  "USA": ["New York", "Los Angeles", "Chicago", "Miami", "Austin", "San Francisco", "Seattle", "Denver"],
  "United Kingdom": ["London", "Manchester", "Birmingham", "Edinburgh", "Bristol", "Glasgow", "Liverpool"],
  "Germany": ["Berlin", "Munich", "Hamburg", "Cologne", "Frankfurt", "Stuttgart", "Düsseldorf"],
  "Romania": ["Bucharest", "Cluj-Napoca", "Timișoara", "Iași", "Constanța", "Brașov", "Sibiu", "Vama Veche"],
};

export const MOCK_ADS: Ad[] = [
  {
    id: 'ad1',
    brand: 'Corona Extra',
    image: 'https://images.unsplash.com/photo-1613946069412-38f7f1ff0b65?q=80&w=400&auto=format&fit=crop',
    tagline: 'Life is better with a cold one.',
    isAdultOnly: true,
    cta: 'Find nearby'
  }
];

export const INITIAL_PARTIES: Party[] = [
  {
    id: 'p1',
    hostId: 'u2',
    hostName: 'Sarah J.',
    title: 'Neon Underground Techno Night',
    theme: 'Cyberpunk / Neon',
    description: 'A night of deep beats and flashing lights in my industrial loft space.',
    date: '2024-05-20 22:00',
    locationName: 'Williamsburg, Brooklyn',
    city: 'New York',
    country: 'USA',
    exactAddress: '123 Kent Ave, Brooklyn, NY 11249',
    preciseLocation: { latitude: 40.7128, longitude: -73.9626 },
    maxGuests: 40,
    currentGuests: ['u5', 'u6'],
    pendingRequests: [],
    price: 15,
    whatToBring: ['Drinks', 'Good Vibes'],
    imageUrl: 'https://picsum.photos/seed/neon/800/400',
    galleryUrls: [
      'https://picsum.photos/seed/party1/400/400',
      'https://picsum.photos/seed/party2/400/400',
      'https://picsum.photos/seed/party3/400/400',
    ],
    includesAlcohol: true
  }
];

export const MOCK_USERS: Record<string, User> = {
  'u2': {
    id: 'u2',
    username: 'sarah_j',
    fullName: 'Sarah Jenkins',
    avatar: 'https://picsum.photos/seed/sarah/200',
    bio: 'Music producer and cocktail enthusiast.',
    isIdVerified: true,
    dob: '1995-02-10',
    email: 'sarah@example.com',
    phone: '+1 555-9999',
    country: 'USA',
    city: 'New York',
    address: 'Brooklyn Loft 4B',
    hostRating: 4.9,
    guestRating: 4.7,
    reviewsAsHost: [
      { id: 'rh1', authorId: 'u5', authorName: 'James', authorAvatar: 'https://picsum.photos/seed/u5/100', content: 'The atmosphere was electric! Sarah is an amazing host who makes everyone feel welcome.', rating: 5, date: '2024-01-10', type: 'asHost' }
    ],
    reviewsAsGuest: [],
    preferences: { notifications: true, darkMode: false, radius: 50 }
  },
  'u5': {
    id: 'u5',
    username: 'james_k',
    fullName: 'James Kovach',
    avatar: 'https://picsum.photos/seed/u5/200',
    bio: 'Loves dancing and good snacks.',
    isIdVerified: true,
    dob: '1992-11-20',
    email: 'james@example.com',
    phone: '+1 555-8888',
    country: 'USA',
    city: 'New York',
    address: 'Queens Apt 1',
    hostRating: 4.0,
    guestRating: 5.0,
    reviewsAsHost: [],
    reviewsAsGuest: [],
    preferences: { notifications: true, darkMode: false, radius: 50 }
  },
  'u6': {
    id: 'u6',
    username: 'lisa_vibe',
    fullName: 'Lisa Vanderpump',
    avatar: 'https://picsum.photos/seed/u6/200',
    bio: 'Vibe specialist.',
    isIdVerified: true,
    dob: '1988-06-06',
    email: 'lisa@example.com',
    phone: '+1 555-7777',
    country: 'USA',
    city: 'New York',
    address: 'Manhattan Penthouse',
    hostRating: 4.5,
    guestRating: 4.5,
    reviewsAsHost: [],
    reviewsAsGuest: [],
    preferences: { notifications: true, darkMode: false, radius: 50 }
  }
};
